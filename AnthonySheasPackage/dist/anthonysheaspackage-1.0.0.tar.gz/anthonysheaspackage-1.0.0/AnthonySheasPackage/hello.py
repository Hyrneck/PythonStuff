def hello() ->None:
    """Prints a hello message"""
    print("Hello, World!")

